/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aura
 */
public class Hewan {
public void cetakNama(String nama) {
       System.out.println("Nama hewan: " + nama);
    }
}
